/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airportcheck;

import java.nio.file.*;
import java.util.List;

/**
 *
 * @author Mohd Samir
 */
public class ReadCsvFile {
 // String str="";
     public static void readcsvFile(){
          try{
           // List<String> lines= Files.readAllLines(paths.get("src\\readcsvfile\\flightDetails"));
            List<String> lines= Files.readAllLines(Paths.get("src\\\\readcsvfile\\\\flightDetails"));
            for(String line : lines){
                System.out.print(line);
                  System.out.println();      
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
   }
   
