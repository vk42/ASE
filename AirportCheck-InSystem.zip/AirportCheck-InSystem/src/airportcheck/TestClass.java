/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airportcheck;

/**
 *
 * @author Mohd Samir
// */
//public class TestClass {
//    public static void main(String[] args) {
////        TicketCounter ticketCounter = new TicketCounter();
////        TicketBookingThread t1 = new TicketBookingThread(ticketCounter,"John",2);
////        TicketBookingThread t2 = new TicketBookingThread(ticketCounter,"Martin",2);
////        
//        WaitingPass wps= new WaitingPass();
//        MultithreadingUse t1=new MultithreadingUse(wps, "test","name", 1, 25, 200);
//         MultithreadingUse t2=new MultithreadingUse(wps, "tes2","name1", 2, 12, 100);
//
//        t1.start();
//        t2.start();
//    }
//}
