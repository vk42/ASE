/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airportcheck;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Mohd Samir
 */
public class Report extends javax.swing.JFrame {

    
    ArrayList<Report> passengerList;
    String header [] = new String [] {"Passenger check- In" , "Total Weight", "Total volume "," Total access baggage Fee"};
    DefaultTableModel dftm2;
    int row,col;
    /**
     * Creates new form Exit
     */
    public Report() {
        initComponents();
        passengerList =  new ArrayList<>();
        dftm2 = new DefaultTableModel(header,0);
        jTable2.setModel(dftm2);
        this.setLocationRelativeTo(null);
        
    }

    public Report(int arr[]){
        initComponents();
       // jTable1.setT
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        ShowButton = new javax.swing.JButton();
        homepageButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(1280, 780));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 153));
        jLabel1.setText(" Report");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(550, 30, 150, 50);
        jPanel1.add(jLabel3);
        jLabel3.setBounds(399, 63, 0, 0);

        jButton1.setBackground(new java.awt.Color(255, 0, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Logout");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(830, 130, 120, 40);

        ShowButton.setBackground(new java.awt.Color(102, 102, 255));
        ShowButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ShowButton.setText("Show Report");
        ShowButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ShowButtonMouseClicked(evt);
            }
        });
        ShowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowButtonActionPerformed(evt);
            }
        });
        jPanel1.add(ShowButton);
        ShowButton.setBounds(290, 130, 140, 40);

        homepageButton.setBackground(new java.awt.Color(255, 153, 102));
        homepageButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        homepageButton.setText("Home ");
        homepageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homepageButtonActionPerformed(evt);
            }
        });
        jPanel1.add(homepageButton);
        homepageButton.setBounds(570, 130, 130, 40);

        jTable2.setBorder(new javax.swing.border.MatteBorder(null));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(280, 190, 670, 200);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1300, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ShowButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowButtonActionPerformed
      
     
     Flight_Details1 ff= new Flight_Details1();
    Baggage_Details1 b = new Baggage_Details1();
   int v = b.array[0];
   String t = b.array1[0];
  // int x= b.array[2];
   int y = b.array[3];
  // int z = b.array[4];
   int cnt= ff.countCheckIn;
 //  String m = IntegerParse(t);
   
       // System.out.println("t : "+t+"x : "+x+"y : "+y+"z : "+z);
                 dftm2.insertRow(dftm2.getRowCount(), new Object[]{cnt,v,t.toString(),y});

   //dftm2.insertRow(dftm2.getRowCount(), Object[]{});
       
        
    }//GEN-LAST:event_ShowButtonActionPerformed

    private void homepageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homepageButtonActionPerformed
       
        MainPage h = new MainPage();
       h.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_homepageButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        AirportCheckInSystem a=new AirportCheckInSystem();
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ShowButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ShowButtonMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_ShowButtonMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Report().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ShowButton;
    private javax.swing.JButton homepageButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
