/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airportcheck;



/**
 *
 * @author Mohd Samir
 */
public class WaitingPass extends Check_In_Desk {
   // CheckCountForQueue csq = new CheckCountForQueue();
    
   

	public synchronized void checkInBag(String passfname,String passlname, int bag , int bagWt , int ammount) {
//            Check_In_Desk xik = new Check_In_Desk();
           //  DefaultTableModel tableModel =
                //    System.out.println("11:  "+passfname+" 22:   "+passlname+"  33 :   "+bag+"  44 : "+bagWt+"  55 : "+ammount);

            CheckCountForQueue csq = new CheckCountForQueue();
            int waitingInQueue = csq.checkCount();
         //  System.out.println("count for queue :"+waitingInQueue);
             // DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
            
               
                  
         //   System.out.println("cmg........");
            
		if ((waitingInQueue <= bagWt) && (bagWt > 20)) {
                   
//System.out.println( passfname +" "+passlname+ " is dropping off " + bag+ " bag of "+bagWt+"Kg. A baggage fee of £"+ammount+" is due.");
//System.out.println(".......if.........");

dftm25.insertRow(dftm25.getRowCount(),new Object[]{ passfname +" "+passlname+ " is dropping off " + bag+ " bag of "+bagWt+". A baggage fee of £"+ammount+" is due."} );
		//waitingInQueue = waitingInQueue- bagWt;
		} else{
                   // System.out.println(".............else...........");
			//System.out.println( passfname +" "+passlname+ " is dropping off "+bag+" bag of "+bagWt+"Kg. No baggage fee is due.");
                                 dftm25.insertRow(dftm25.getRowCount(),new Object[]{ passfname +" "+passlname+ " is dropping off "+bag+" bag of "+bagWt+". No baggage fee is due."} );
	        }
                
            }
}

    

