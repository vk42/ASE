/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airportcheck;

/**
 *
 * @author Mohd Samir
 */
public class MultithreadingUse extends Thread {
       public static int noOfObjects = 0; 
  
  
    { 
        noOfObjects += 1; 
    } 
    private WaitingPass waitingPass;
    private String passfName;
    private String passlName;
    private int bag;
    private int bagWt;
    private int amountDue;
    public MultithreadingUse(WaitingPass waitingPass,String passfName,String passlName, int bag, int bagWt, int amountDue){
        this.waitingPass= waitingPass;
        this.passfName=passfName;
        this.passlName= passlName;
        this.bag=bag;
        this.bagWt=bagWt;
        this.amountDue= amountDue;
        
    }

 
    @Override
      public void run(){
         //   System.out.println(".......run.........");
            waitingPass.checkInBag(passfName,passlName, bag, bagWt, amountDue);
        }
            
        }
    
    

    


